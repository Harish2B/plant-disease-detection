### Predicting the affected plant using the pictures of the leaves with the help of ResNet.
